function navbar() {
    return `

    <div id="navbar">
            <div id="left">
                <h3><a href="./index.html">home</a></h3>
                
            
            </div>
            <div id="right">
                <input  id="search" type="text"placeholder="search">
                <button onclick="searchfun()">search</button>
        
                <h3><a href="latestRecipe.html">Latest Recipe</a></h3> 
                <h3><a href="RecipeOfTheDay.html">Recipe of the day</a></h3>
            </div>
            
            
            
            </div>
            
            <div id="container"</div>`
}

export default navbar







