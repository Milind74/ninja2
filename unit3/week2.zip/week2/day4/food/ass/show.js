//https://www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata



async function getData(url) {
    let res = await fetch(url);
      let data = await res.json();
      console.log(data.meals)

      return data.meals
  }

  // async function getData1(url) {
  //   let res1 = await fetch(url);
  //     let data1 = await res1.json();
  //     console.log(data1.meals)

  //     return data1.meals
  // }

  
  function append(d,container) {

    d.forEach(({ strMeal, strMealThumb }) => {
      let div = document.createElement("div");
      let p = document.createElement("p");
      p.innerText = strMeal
      let img = document.createElement("img");
      img.src = strMealThumb
      div.append(img, p)
  
      container.append(div);
    });
  }

  
  
  export {getData, append};
 