import logo from './logo.svg';
import './App.css';
import { Todos } from './Components/Input';

function App() {
  return (
    <div className="App">
      <Todos/>
      
    </div>
  );
}

export default App;
