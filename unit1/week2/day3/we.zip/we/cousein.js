for (i = 50; i <= 150; i++){
    if (i % 7 == 0) {
        console.log(i)
    }
}