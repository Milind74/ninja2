// for (i = 1; i <= 10; i++){
//     console.log("square of " +i+" is " +i*i)
// }

var i=1
while (i <= 10) {
    console.log(`square of ${i} is ${i * i}`)

    i++
}