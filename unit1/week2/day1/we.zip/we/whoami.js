var side=4
        if(side==3){
            console.log("Tringle")
        }
      else  if(side==4){
            console.log("quadrilateral")
        }

        else   if(side==5){
                console.log("pentagon")
            }

            
            else     if(side==6){
                    console.log("hexagon")
                }
                else     if(side==7){
                    console.log("septagon")
                }
                else     if(side==8){
                    console.log("octagon")
                }
                else     if(side==9){
                    console.log("nonagon")
                }
                else     if(side==10){
                    console.log("decagon")
                }
    
            

