var indiascore=40
var pakscore=30
if(indiascore>pakscore){
    console.log("India Wins")
}
else if(pakscore>indiascore){
    console.log("pakistan win")

}
else if(indiascore==pakscore){
    console.log("tied")
}