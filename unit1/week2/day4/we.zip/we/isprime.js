var isprime = true
var n = 17
for (i = 2; i < n - 1; i++){
    if (n % i == 0) {
        isprime = false
        break;
    }
}
if (isprime) {
    console.log("prime")
}
else {
    console.log("not prime")
}