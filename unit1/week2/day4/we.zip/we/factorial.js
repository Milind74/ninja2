var n = 4
var fact=1
for (i = 1; i <= n; i++){
    var fact= fact *i
}
console.log(fact)