
//name a thon
var averageAge=30
var numberOfStudents="MILIND ANAND"
var maximumMarks=85
var theFirstName ="MILIND"
var numberOfStudentsIn12thClass=70
