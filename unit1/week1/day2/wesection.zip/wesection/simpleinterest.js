/*    simple interest=principal*time*rate/100     */

var principal=2000 //this is principal amount
var rate=5 //this is annual interest
var time=10 //this is time in years
var si=(principal*time*rate)/100
console.log(si)
