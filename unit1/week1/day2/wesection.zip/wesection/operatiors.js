var a=10;
a+=2
a-=3
a*=6
a/=6
a%=7
console.log(a)