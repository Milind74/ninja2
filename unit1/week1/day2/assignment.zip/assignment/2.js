var a=true||false  || false &&  false
console.log("Not Possible"+a)    //false

var b=  true|| true && false ||  true
      console.log(b) //

var c=false || true || false||    false && true
console.log("Not Possible")//false 

var d=false && true ||  true|| true && false
console.log(d)  //true=false||true&&false

var e=false ||false  ||false  && true || false
console.log(e)//false=  falsefalse&&true