console.log(typeof 1729);
console.log(typeof "Masai School");
console.log(typeof false)
console.log(typeof "")
console.log(typeof undefined)