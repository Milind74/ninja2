var firstName="milind"
var lastName="anand"
var age=22
var address="navratan hata purnia"
var city= "purnia"
var state="bihar"
var pincode=854301
console.log("my name is " +" "+firstName + " " +lastName)
console.log("my age is "+ " " +age)
console.log("my address is"+" " +address)
console.log("my city name is "+" " +city)
console.log("my state is bihar"+" "+state)
console.log("my pincode is"+" "+pincode)