var address={
    House_Number:12345,
        Area:"navratan hata",
        City:"purnia",
        State:"bihar",
        Pincode:854301,
        Mobile_Number:6206039202,
            greet:function(){
                console.log("hello world")
            }
};
console.log(address)
address.greet()