var name={
    year:1998,
     age:function(){
         console.log(2020-1998)
     }
}
name.age()